package swing.frame;

public class TestFrame {

	public static void main(String[] args) {
		BackGroundFrame tf = new BackGroundFrame("BackGroundFrame");
	}

}
