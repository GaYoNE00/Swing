package swing.components;

public class TestFrame {

	public static void main(String[] args) {
		ChatFrame tf = new ChatFrame("ChatFrame");
	}

}
