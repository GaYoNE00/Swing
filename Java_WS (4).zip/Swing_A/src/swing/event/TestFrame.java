package swing.event;



public class TestFrame {

	public static void main(String[] args) {
		MouseEventFrame tf = new MouseEventFrame("MouseEventFrame");
	}

}
