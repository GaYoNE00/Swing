package project2;

public class Main {

	public static void main(String[] args) {
		MainFrame mf = new MainFrame("메인 프레임", 600, 400);
		
	}

}
