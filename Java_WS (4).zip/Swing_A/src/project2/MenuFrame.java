package project2;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MenuFrame extends JFrame{

	private JButton btn1;
	private JButton btn2;
	public MenuFrame(String title) {
		setTitle(title);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		setLocation(1300, 300);
		setLocationRelativeTo(null);
		setSize(100, 200);
//		setLayout(new BorderLayout());
		
//		setLayout(new GridLayout(2, 1, 10, 10));
		setpanelCenter();
		
//		btn1 = new JButton();
//		btn2 = new JButton();
//	
//		add(btn1);
//		add(btn2);
		
		setVisible(true);
	}
//	private void setpanelCenter() {
//		JPanel panelCenter = new JPanel();
//		
//		JButton btn1 = new JButton("메뉴 1");
//		JButton btn2 = new JButton("메뉴 2");		
//		
//		panelCenter.add(btn1);
//		panelCenter.add(btn2);
//		
//		add(panelCenter);
//		
//	}
	private void setpanelCenter() {
		JPanel panelCenter = new JPanel();
		
//		panelCenter.setLayout(new GridLayout(2,1, 10, 10));
		panelCenter.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		JButton btn1 = new JButton("메뉴 1");
		JButton btn2 = new JButton("메뉴 2");		
		
		panelCenter.add(btn1);
		btn1.setPreferredSize(new Dimension(90,60));
		panelCenter.add(btn2);
		btn2.setPreferredSize(new Dimension(90,60));
		
		add(panelCenter);
		
	}
	public static void main(String[] args) {
		new MenuFrame("메뉴프레임");
	}
}
