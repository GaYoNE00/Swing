package project;

public class Main {

	public static void main(String[] args) {
		MainFrame mf = new MainFrame("내 프로젝트", 600, 400);
		
		
	}

}
