package project;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import project2.ChatFrame;

public class MainFrame extends JFrame implements ActionListener, ListSelectionListener, MouseListener{
	private JList<String> list;
	private Vector<String> veclist;
	private JLabel imglabel;
	private JMenuItem itemnew;
	private JMenuItem itemInfo;
	private JMenuItem itemopen;
	private JMenuItem itemsave;
	private JMenuItem itemexit;
	private JButton btnNew;
	private JButton btnOpen;
	private JButton btnSave;
	private JButton btnExit;
	private JComboBox<String> Jcombo;
	private Vector<String> veccombo;
	private JTextField tf;
	private DefaultListModel<String> model;
	public MainFrame(String title, int width, int height) {
		setTitle(title);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocation(600, 300);
		setSize(width, height);
		setLayout(new BorderLayout());
		
		setMenu();
		setToolbar();
		setPannelcenter();
		
		
		
		setVisible(true);
	}

	private void setMenu() {
		JMenuBar menubar = new JMenuBar();
		JMenu menuFile = new JMenu("파일");
		itemnew = new JMenuItem("새파일");
		itemopen = new JMenuItem("열기");
		itemsave = new JMenuItem("저장");
		itemexit = new JMenuItem("종료");
		itemexit.addActionListener(this);
		
		menuFile.add(itemnew);
		menuFile.add(itemopen);
		menuFile.add(itemsave);
		menuFile.addSeparator();	
		menuFile.add(itemexit);
		
		JMenu menuproject = new JMenu("project");
		JMenu menuhelp = new JMenu("도움말");
		itemInfo = new JMenuItem("프로그램 정보");
		itemInfo.addActionListener(this);
		menuhelp.add(itemInfo);
	
		
		menubar.add(menuFile);
		menubar.add(menuproject);
		menubar.add(menuhelp);
		
		setJMenuBar(menubar);
	}

	private void setToolbar() {
		JToolBar toolbar = new JToolBar("내 툴바");
		ImageIcon iconNew = new ImageIcon("images/new.png");
		ImageIcon iconOpen = new ImageIcon("images/open.png");
		ImageIcon iconSave = new ImageIcon("images/save.png");
		ImageIcon iconExit = new ImageIcon("images/exit.png");
		
		btnNew = new JButton(iconNew);
		btnNew.addActionListener(this);
		btnOpen = new JButton(iconOpen);
		btnSave = new JButton(iconSave);
		btnExit = new JButton(iconExit);
		btnExit.addActionListener(this);
		
		toolbar.add(btnNew);
		toolbar.add(btnOpen);
		toolbar.add(btnSave);
		toolbar.addSeparator();
		toolbar.add(btnExit);

		
		toolbar.add(new JLabel("Search:"));
		
		tf = new JTextField(10);
		tf.addActionListener(this);
		
		toolbar.add(tf);
		
		veccombo = new Vector<String>();
		veccombo.add("aaa");
		veccombo.add("bbb");
		veccombo.add("ccc");
		
		Jcombo = new JComboBox<String>(veccombo);
		toolbar.add(Jcombo);
		add(toolbar, BorderLayout.NORTH);
	}

	private void setPannelcenter() {
		model = new DefaultListModel<String>();
		model.addElement("사과");
		model.addElement("배");
		model.addElement("체리");
		
		
		list = new JList<>(model);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.addListSelectionListener(this);
		list.addMouseListener(this);
		
		ImageIcon img = new ImageIcon("images/gosling.jpg");
		imglabel = new JLabel(img);
		
		JScrollPane sp = new JScrollPane(imglabel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JSplitPane jsp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, list, sp); 
		
		jsp.setDividerLocation(150);
		
		add(jsp);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == itemexit || obj == btnExit) {
			if(JOptionPane.showConfirmDialog(this,"정말 종료할까요?" ,"프로그램 종료",
					JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE)==JOptionPane.YES_OPTION) {
				System.exit(0);
			}
		}else if(obj == tf) {
			addItem();
		}else if(obj == itemInfo) {
			JOptionPane.showMessageDialog(this, "프로그램 작성 by 김영호 ver1.0");
		}
		
	}

	private void addItem() {
		String text = tf.getText();
		model.addElement(text);
		tf.setText("");
		tf.requestFocus();
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		System.out.println(list.getSelectedValue());
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getClickCount() == 2) {
			if(list.getSelectedIndex()!=-1) {
				veccombo.add(list.getSelectedValue());
				model.remove(list.getSelectedIndex());				
			}
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
